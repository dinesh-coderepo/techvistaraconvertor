/
├── app.py
├── main.py
├── static/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── script.js
├── templates/
│   └── index.html
└── uploads/
    ├── audio/
    ├── images/
    └── videos/